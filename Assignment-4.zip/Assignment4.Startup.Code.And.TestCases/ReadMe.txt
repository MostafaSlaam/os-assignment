STEPS:
======
1. REFER to documentation for IMPORTANT INSTRUCTIONS
2. Run! results of testing each question with the corresponding grade will be printed JUST BEFORE the "FOS>" prompt

NOTE:
=====
This is an automatic testing for your code. It's very similar to the one that will be used in evaluation.
So, make sure that you pass these tests before submitting your code to the form... 
